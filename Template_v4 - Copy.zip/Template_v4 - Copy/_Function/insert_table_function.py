import os
from pptx import Presentation
from pptx.enum.text import PP_ALIGN
from pptx.util import Inches, Pt

def insert_table(file_ppt,_slide,_table,_row,_valve,_size,_lenght):
	try:
		prs = Presentation(file_ppt)
	except FileNotFoundError:
		prs = Presentation()
	slide = prs.slides[_slide]
	table_count = 0
	for shape in slide.shapes:
		if shape.has_table:
			table_count += 1
			if table_count == _table:
				table = shape.table
				row_idx = _row
				for col_idx, value_to_insert in zip(range(1,_lenght), _valve):
					cell = table.cell(row_idx, col_idx)
					cell_text = cell.text
					numeric_part, _, suffix = cell_text.partition(" ")
					formatted_value = f"{value_to_insert}{suffix}"
					cell.text = formatted_value
					for paragraph in cell.text_frame.paragraphs:
						paragraph.alignment = PP_ALIGN.CENTER
						for run in paragraph.runs:
							run.font.name = "MS P"
							run.font.size = Pt(_size)
				break

	prs.save(file_ppt)
# file_ppt = r"C:\Users\TechnoStar\Documents\Valve_missalignment\Template_v3_update_3_4_bore\_Function\Template.pptx"
# _d_ex = [[29.6, 30.6, 27.0, 30.0, 29.3, 30.6], [22.8, 21.4, 17.1, 22.8, 20.3, 25.1]]

# insert_table(file_ppt,1,1,2,_d_ex[0],9,9)