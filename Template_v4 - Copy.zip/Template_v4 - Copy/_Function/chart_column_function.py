import os
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.text import PP_ALIGN
def chart_column(file_ppt, list_assy, list_heat, x, y, cx, cy, _slide):
	try:
	    prs = Presentation(file_ppt)
	except FileNotFoundError:
	    prs = Presentation()

	chart_data = CategoryChartData()
	if len(list_assy) == 6:
		chart_data.categories = ['EX1', 'EX2', 'EX3', 'EX4', 'EX5', 'EX6']		
	if len(list_assy) == 8:
		chart_data.categories = ['EX1', 'EX2', 'EX3', 'EX4', 'EX5', 'EX6', 'EX7', 'EX8']
	chart_data.add_series('ASSY', list_assy)
	chart_data.add_series('HEAT', list_heat)

	slide = prs.slides[_slide]

	chart = slide.shapes.add_chart(
	    XL_CHART_TYPE.COLUMN_CLUSTERED, x, y, cx, cy, chart_data
	).chart
	
	chart.value_axis.has_title = True
	chart.value_axis.axis_title.text_frame.text = "同車度(µm)"
	chart.value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.bold = False
	chart.value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(9)

	chart.category_axis.has_title = True
	chart.category_axis.axis_title.text_frame.text = "排気測"
	chart.category_axis.axis_title.text_frame.paragraphs[0].runs[0].font.bold = False
	chart.category_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(9)

	chart.value_axis.number_format = '0'
	chart.value_axis.major_unit = 10
	chart.value_axis.minor_unit = 5
	chart.value_axis.minimum_scale = 0
	chart.value_axis.maximum_scale = 100

	chart.value_axis.tick_labels.font.bold = False
	chart.value_axis.tick_labels.font.size = Pt(9)

	chart.category_axis.tick_labels.font.bold = False
	chart.category_axis.tick_labels.font.size = Pt(9)

	chart.value_axis.major_gridlines.format.line.color.rgb = RGBColor(231,230,230)
	chart.value_axis.major_gridlines.format.line.width = Pt(0.5)
	chart.value_axis.major_gridlines.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH

	series = chart.series[0]
	fill = series.format.fill
	fill.solid()
	fill.fore_color.rgb = RGBColor(192, 80, 77)

	line = series.format.line
	line.fill.solid()
	line.fill.fore_color.rgb = RGBColor(0, 0, 0)
	line.width = Pt(0.5)

	series = chart.series[1]
	fill = series.format.fill
	fill.solid()
	fill.fore_color.rgb = RGBColor(91, 155, 213)

	line = series.format.line
	line.fill.solid()
	line.fill.fore_color.rgb = RGBColor(0, 0, 0)
	line.width = Pt(0.5)

	prs.save(file_ppt)

# file_ppt = r"C:\Users\TechnoStar\Documents\Valve_missalignment\Template_v3_update_3_4_bore\_Function\Template.pptx"
# _d_ex = [[29.6, 30.6, 27.0, 30.0, 29.3, 30.6], [22.8, 21.4, 17.1, 22.8, 20.3, 25.1]]
# chart_column(file_ppt, _d_ex[0], _d_ex[1], Inches(5.5), Inches(2.2), Inches(3.94), Inches(2.5), 1)
# chart_column(file_ppt, _d_ex[0], _d_ex[1], Inches(0.25), Inches(2.2), Inches(3.94), Inches(2.5), 1)