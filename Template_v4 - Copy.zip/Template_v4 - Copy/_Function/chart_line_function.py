import os
from pptx import Presentation
from pptx.chart.data import XySeriesData, XyChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_DATA_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.dml import MSO_THEME_COLOR, MSO_LINE_DASH_STYLE
from pptx.enum.text import PP_ALIGN
def chart_line(file_ppt, list, x, y, cx, cy, _slide):
	try:	
		prs = Presentation(file_ppt)
	except FileNotFoundError:
		prs = Presentation()
	category_labels = ['point1', 'point2']
	chart_data = XyChartData()

	for i in range(0,int(len(list[0])/2)):
		series_data_assy = [(0,0), (list[0][2*i+1], list[0][2*i])]
		series_assy = chart_data.add_series(f'ASSY{i+1}')
		for point in series_data_assy:
			series_assy.add_data_point(point[0], point[1])
		series_data_heat = [(list[0][2*i+1], list[0][2*i]), (list[1][2*i+1], list[1][2*i])]
		series_heat = chart_data.add_series(f'ASSY{i+1}')
		for point in series_data_heat:
			series_heat.add_data_point(point[0], point[1])
			series_heat.color = RGBColor(231,230,230)
	slide = prs.slides[_slide]
	chart = slide.shapes.add_chart(XL_CHART_TYPE.XY_SCATTER_LINES, x, y, cx, cy, chart_data).chart

	chart.has_legend = False

	chart.value_axis.has_title = True
	chart.value_axis.axis_title.text_frame.text = "Y方白変位里基(µm)"
	chart.value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.bold = False
	chart.value_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(9)

	chart.category_axis.has_title = True
	chart.category_axis.axis_title.text_frame.text = "Y方白変位里基(µm)"

	chart.category_axis.axis_title.text_frame.paragraphs[0].runs[0].font.bold = False
	chart.category_axis.axis_title.text_frame.paragraphs[0].runs[0].font.size = Pt(9)

	chart.value_axis.number_format = '0'
	chart.value_axis.major_unit = 10.0
	chart.value_axis.minor_unit = 10.0
	chart.value_axis.minimum_scale = -50.0
	chart.value_axis.maximum_scale = 50.0

	chart.category_axis.major_unit = 10.0
	chart.category_axis.minor_unit = 10.0
	chart.category_axis.minimum_scale = -50.0
	chart.category_axis.maximum_scale = 50.0

	chart.value_axis.tick_labels.font.bold = False
	chart.value_axis.tick_labels.font.size = Pt(9)

	chart.category_axis.tick_labels.font.bold = False
	chart.category_axis.tick_labels.font.size = Pt(9)

	chart.value_axis.major_gridlines.format.line.color.rgb = RGBColor(231,230,230)
	chart.value_axis.major_gridlines.format.line.width = Pt(0.5)
	chart.value_axis.major_gridlines.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH

	color_list = [[0, 0, 153],[192, 0, 0],[146, 208, 80],[112, 48, 160],[56, 87, 35],[255, 192, 0],[157, 195, 230],[255, 0, 255]]
	for i in range(0,int(len(list[0])/2)):
		chart.series[2*i].format.line.dash_style = MSO_LINE_DASH_STYLE.ROUND_DOT
		chart.series[2*i].format.line.width = Pt(2)

		chart.series[2*i].format.line.color.rgb = RGBColor(color_list[i][0], color_list[i][1], color_list[i][2])	
		chart.series[2*i+1].format.line.color.rgb = RGBColor(color_list[i][0], color_list[i][1], color_list[i][2])

		chart.series[2*i].marker.style = XL_MARKER_STYLE.CIRCLE
		chart.series[2*i].marker.size = 7
		chart.series[2*i].marker.format.fill.solid()
		chart.series[2*i].marker.format.fill.fore_color.rgb = RGBColor(color_list[i][0], color_list[i][1], color_list[i][2])

		chart.series[2*i+1].marker.style = XL_MARKER_STYLE.CIRCLE
		chart.series[2*i+1].marker.size = 7
		chart.series[2*i+1].marker.format.fill.solid()
		chart.series[2*i+1].marker.format.fill.fore_color.rgb = RGBColor(color_list[i][0], color_list[i][1], color_list[i][2])

	for s in chart.series:
		s.marker.size = 5
		s.marker.style = XL_MARKER_STYLE.CIRCLE

	prs.save(file_ppt)
# file_ppt = r"C:\Users\TechnoStar\Documents\Valve_missalignment\Template_v3_update_3_4_bore\_Function\Template.pptx"
# _denta_ex = [[30,5,30,10,30,15,30,20,30,25,30,30], [40,20,40,20,40,20,40,20,40,20,40,20]]
# chart_line(file_ppt, _denta_ex, Inches(6.5), Inches(5.4), Inches(2.2), Inches(2.153), 1)
# # chart_line(file_ppt, _denta_ex, Inches(1.8), Inches(5.4), Inches(2.2), Inches(2.153), 1)
